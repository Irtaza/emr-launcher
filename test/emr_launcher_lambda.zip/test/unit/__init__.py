import aws
import manifest
import moto